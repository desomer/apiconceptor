# OpenCode REST API Plugin

Plugin local pour **OpenCode Desktop** et **OpenCode TUI** permettant de piloter OpenCode et d'interagir avec le projet en cours via une API REST sur `localhost`.

---

## Sommaire

1. [Installation & Configuration](#installation--configuration)
2. [Résumé des Routes](#résumé-des-routes)
3. [Détail des Routes et Exemples cURL](#détail-des-routes-et-exemples-curl)
   - [1. Santé du serveur (`GET /api/health`)](#1-santé-du-serveur-get-apihealth)
   - [2. Lister les sessions (`GET /api/sessions`)](#2-lister-les-sessions-get-apisessions)
   - [3. Obtenir les chemins du plugin et de configuration (`GET /api/plugin/path`)](#3-obtenir-les-chemins-du-plugin-et-de-configuration-get-apipluginpath)
   - [4. Exécuter un prompt (`POST /api/prompt`)](#4-exécuter-un-prompt-post-apiprompt)
   - [5. Pré-remplir la zone de saisie Desktop (`POST /api/type`)](#5-pré-remplir-la-zone-de-saisie-desktop-post-apitype)
   - [6. Créer / modifier un fichier UTF-8 (`POST /api/file`)](#6-créer--modifier-un-fichier-utf-8-post-apifile)
4. [Remarques](#remarques)

---

## Installation & Configuration

Le plugin est auto-découvert depuis `.opencode/plugin/rest-api.ts`. Vous pouvez également le configurer dans `opencode.json` :

```json
{
  "$schema": "https://opencode.ai/config.json",
  "plugin": [
    ["./.opencode/plugin/rest-api.ts", { "port": 4567, "host": "127.0.0.1" }]
  ]
}
```

- **Port par défaut :** `4567` (modifiable via l'option `port` ou la variable d'environnement `OPENCODE_REST_PORT`)
- **Host par défaut :** `127.0.0.1` (modifiable via l'option `host` ou la variable d'environnement `OPENCODE_REST_HOST`)

> **Important :** Chaque modification de la configuration ou du code du plugin nécessite de **quitter et redémarrer OpenCode Desktop**.

---

## Résumé des Routes

| Méthode | Route | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Vérifie que le plugin et le serveur HTTP sont actifs |
| `GET` | `/api/sessions` | Liste les sessions de travail gérées par OpenCode |
| `GET` | `/api/plugin/path` *(ou `/api/plugin`)* | Retourne les chemins d'installation et de configuration du plugin |
| `POST` | `/api/prompt` | Exécute un prompt dans la session active ou spécifiée |
| `POST` | `/api/type` *(ou `/api/input`)* | Insère le prompt dans la zone de texte d'OpenCode Desktop |
| `POST` / `PUT` | `/api/file` *(ou `/api/files`)* | Ajoute ou met à jour un fichier UTF-8 dans le projet en cours |

---

## Détail des Routes et Exemples cURL

### 1. Santé du serveur (`GET /api/health`)

Vérifie la connectivité et le statut du serveur REST.

#### Requête cURL
```bash
curl -X GET http://127.0.0.1:4567/api/health
```

#### Exemple de réponse
```json
{
  "status": "ok",
  "service": "opencode-rest-api",
  "port": 4567,
  "host": "127.0.0.1",
  "timestamp": "2026-09-17T21:40:00.000Z"
}
```

---

### 2. Lister les sessions (`GET /api/sessions`)

Retourne la liste des sessions avec leurs identifiants, titres et répertoires associés.

#### Requête cURL
```bash
curl -X GET http://127.0.0.1:4567/api/sessions
```

#### Exemple de réponse
```json
{
  "success": true,
  "sessions": [
    {
      "id": "ses_f4f3b3180ffe73Q2Hkp8Ak7Hdo",
      "slug": "sunny-moon",
      "projectID": "global",
      "directory": "C:\\dev\\pluginOpenCode",
      "title": "Créer un plugin OpenCode pour API REST locale"
    }
  ]
}
```

---

### 3. Obtenir les chemins du plugin et de configuration (`GET /api/plugin/path`)

Retourne le chemin exact du fichier de configuration (`opencode.json`) permettant de déclarer le plugin, ainsi que le chemin absolu du fichier source du plugin.

*Alias supportés : `/api/plugin/path`, `/api/plugin`, `/api/config/path`.*

#### Requête cURL
```bash
curl -X GET http://127.0.0.1:4567/api/plugin/path
```

#### Exemple de réponse
```json
{
  "success": true,
  "configFile": "C:\\dev\\pluginOpenCode\\opencode.json",
  "configFileExists": true,
  "pluginFile": "C:\\dev\\pluginOpenCode\\.opencode\\plugin\\rest-api.ts",
  "pluginFileExists": true,
  "globalConfigFile": "C:\\Users\\nom\\.config\\opencode\\opencode.json",
  "globalConfigFileExists": false,
  "directory": "C:\\dev\\pluginOpenCode",
  "installInstructions": {
    "fileToEdit": "C:\\dev\\pluginOpenCode\\opencode.json",
    "configSnippet": {
      "$schema": "https://opencode.ai/config.json",
      "plugin": [
        ["./.opencode/plugin/rest-api.ts", { "port": 4567, "host": "127.0.0.1" }]
      ]
    }
  }
}
```

---

### 4. Exécuter un prompt (`POST /api/prompt`)

Envoie un prompt au moteur d'OpenCode. Si aucun `sessionId` n'est fourni, la requête utilise automatiquement la session en cours la plus récente.

#### Paramètres JSON
| Champ | Type | Obligatoire | Description |
| :--- | :--- | :--- | :--- |
| `prompt` | `string` | **Oui** | Instruction à exécuter |
| `sessionId` | `string` | Non | Identifiant de session (réutilise la session active par défaut) |
| `agent` | `string` | Non | Agent cible (`build`, `general`, etc.) |
| `title` | `string` | Non | Titre de la session si une nouvelle session est créée |

#### Requête cURL
```bash
curl -X POST http://127.0.0.1:4567/api/prompt \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"prompt": "Dis bonjour et liste 3 fichiers du dossier"}'
```

#### Exemple de réponse
```json
{
  "success": true,
  "sessionId": "ses_f4f3b3180ffe73Q2Hkp8Ak7Hdo",
  "response": "Bonjour ! Voici 3 fichiers : package.json, opencode.json, index.ts",
  "parts": [...],
  "info": { "role": "assistant" }
}
```

---

### 5. Pré-remplir la zone de saisie Desktop (`POST /api/type`)

Met au premier plan la fenêtre **OpenCode Desktop** et pré-remplit la barre de saisie de prompt (input) avec le texte spécifié.

#### Paramètres JSON
| Champ | Type | Obligatoire | Description |
| :--- | :--- | :--- | :--- |
| `prompt` *(ou `text`)* | `string` | **Oui** | Texte à insérer dans la zone de prompt |
| `submit` | `boolean` | Non | `true` pour valider et exécuter immédiatement (`false` par défaut) |
| `directory` | `string` | Non | Répertoire du projet cible (dossier courant par défaut) |

#### Requête cURL (Pré-remplissage simple sans validation)
```bash
curl -X POST http://127.0.0.1:4567/api/type \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"prompt": "Explique l architecture du projet", "submit": false}'
```

#### Requête cURL (Pré-remplissage avec envoi automatique)
```bash
curl -X POST http://127.0.0.1:4567/api/type \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"prompt": "Lance les tests unitaires", "submit": true}'
```

#### Exemple de réponse
```json
{
  "success": true,
  "action": "prefilled_in_desktop",
  "text": "Explique l architecture du projet",
  "deepLink": "opencode://new-session?directory=...&prompt=...",
  "message": "Le prompt a été envoyé vers la zone de saisie d'OpenCode Desktop."
}
```

---

### 6. Créer / modifier un fichier UTF-8 (`POST /api/file`)

Crée ou met à jour un fichier avec encodage **UTF-8** dans l'arborescence du projet actif. Les sous-dossiers nécessaires sont créés automatiquement.

*Alias supportés : méthode `POST` ou `PUT`, route `/api/file` ou `/api/files`.*

#### Paramètres JSON
| Champ | Type | Obligatoire | Description |
| :--- | :--- | :--- | :--- |
| `path` | `string` | **Oui** | Chemin relatif (ex: `src/config.json`) ou absolu |
| `content` | `string` | **Oui** | Contenu du fichier encodé en UTF-8 |

#### Requête cURL
```bash
curl -X POST http://127.0.0.1:4567/api/file \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{"path": "config/settings.json", "content": "{\"theme\": \"sombre\", \"debug\": true}"}'
```

#### Exemple de réponse
```json
{
  "success": true,
  "path": "config/settings.json",
  "fullPath": "C:\\dev\\pluginOpenCode\\config\\settings.json",
  "bytes": 35,
  "message": "Fichier écrit avec succès en UTF-8"
}
```

---

## Remarques

- **CORS activé :** Tous les endpoints acceptent les requêtes cross-origin (`Access-Control-Allow-Origin: *`).
- **Encodage UTF-8 sous Windows :** Sous PowerShell ou Windows Terminal, assurez-vous d'envoyer l'en-tête `Content-Type: application/json; charset=utf-8` ou d'utiliser `[System.Text.Encoding]::UTF8.GetBytes()` pour préserver les caractères accentués.
- **Tests :** Pour exécuter la suite de tests automatisée :
  ```bash
  npm test
  ```
